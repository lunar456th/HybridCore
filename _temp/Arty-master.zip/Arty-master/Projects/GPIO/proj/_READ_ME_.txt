In order to run the create_project script successfully, the folder must be in its initial state
containing only the cleanup, create_project scripts, and this document. 

To restore the folder to its initial state, double-click the cleanup Windows Command Script.

!!!!CAUTION!!!!

Moving or copying the cleanup Windows Command Script can result in unintentional loss of data on your
system. The script contains a short list of specific files to ignore once it is run, all other files
and folders within its directory location will be ERASED. Use this only within the project folder as 
instructed.

See material on the usage of demo projects at reference.digilentinc.com