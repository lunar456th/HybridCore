# MIPS
MIPS 5 stage pipeline datapath
